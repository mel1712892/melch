const html = {
    icon: "../../images/icons/skills/html.png",
    label: "HTML",
  };
  
  const css = {
    icon: "../../images/icons/skills/css.png",
    label: "CSS",
  }; 
  const wpf = {
    icon: "../../images/icons/skills/wpf.png",
    label: "WPF",
  };
  
  const winforms = {
    icon: "../../images/icons/skills/winforms.png",
    label: "WinForms",
  };
  
  const csharp = {
    icon: "../../images/icons/skills/csharp.svg",
    label: "C#",
  };
  
  const sqlServer = {
    icon: "../../images/icons/skills/ms-sql-server.png",
    label: "Microsoft Sql Server",
  };
  const java = {
    icon: "../../images/icons/skills/java.png",
    label: "Java",
  };
  
  const laravel = {
    icon: "../../images/icons/skills/laravel.png",
    label: "Laravel",
  };

  const c = {
    icon: "../../images/icons/skills/c.png",
    label: "C",
  };

  const arduino = {
    icon: "../../images/icons/skills/arduino.png",
    label: "Arduino",
  };
 
  const stm32 = {
    icon: "../../images/icons/skills/STM32.png",
    label: "STM32",
  };
  export const skills = [
    csharp,
    wpf,
    winforms,
    sqlServer,
    html,
    css,
    java,
    laravel,
    c,
    arduino,
    stm32,
  ];
  